

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminManagementSystem extends JFrame {
    private JTextField adminUsernameField;
    private JPasswordField adminPasswordField;
    private JButton adminLoginButton;
    private JButton logoutButton;
    private JTable adminComplaintsTable;
    private JComboBox<String> statusComboBox;
    private JButton updateStatusButton;

    private Connection connection;
    private String loggedInAdmin;

    public AdminManagementSystem() {
        setTitle("Admin Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Background Image
        ImageIcon backgroundImage = new ImageIcon("background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);

        // Login Panel
        JPanel adminLoginPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        adminLoginPanel.setOpaque(false);
        adminLoginPanel.setBorder(BorderFactory.createTitledBorder(
                new LineBorder(Color.WHITE, 2), "Admin Login",
                TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.CENTER,
                new Font("Arial", Font.BOLD, 16), Color.BLACK));
        adminUsernameField = new JTextField(20);
        adminPasswordField = new JPasswordField(20);
        adminLoginButton = new JButton("Login");
        logoutButton = new JButton("Logout");
        logoutButton.setEnabled(false);

        adminLoginPanel.add(new JLabel("Admin Username:"));
        adminLoginPanel.add(adminUsernameField);
        adminLoginPanel.add(new JLabel("Admin Password:"));
        adminLoginPanel.add(adminPasswordField);
        adminLoginPanel.add(adminLoginButton);
        adminLoginPanel.add(logoutButton);
        add(adminLoginPanel, BorderLayout.NORTH);

        DefaultTableModel model = new DefaultTableModel(new Object[]{"Complaint ID", "Username", "Complaint", "Status", "Role"}, 0);
        adminComplaintsTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(adminComplaintsTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        // Status Panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        statusPanel.setOpaque(false);
        statusPanel.setBorder(BorderFactory.createTitledBorder(
                new LineBorder(Color.WHITE, 2), "Update Complaint Status",
                TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION,
                new Font("Arial", Font.BOLD, 16), Color.BLACK));
        statusPanel.add(new JLabel("Select Status:"));
        statusComboBox = new JComboBox<>(new String[]{"Pending", "Resolved", "Rejected"});
        statusPanel.add(statusComboBox);
        updateStatusButton = new JButton("Update Status");
        statusPanel.add(updateStatusButton);
        add(statusPanel, BorderLayout.SOUTH);

        // Button Styling
        adminLoginButton.setBackground(Color.WHITE);
        adminLoginButton.setForeground(Color.BLACK);
        logoutButton.setBackground(Color.WHITE);
        logoutButton.setForeground(Color.BLACK);
        updateStatusButton.setBackground(Color.WHITE);
        updateStatusButton.setForeground(Color.BLACK);

        // Button Font
        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        adminLoginButton.setFont(buttonFont);
        logoutButton.setFont(buttonFont);
        updateStatusButton.setFont(buttonFont);

        // Event Listeners
        adminLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = adminUsernameField.getText();
                char[] password = adminPasswordField.getPassword();

                if (authenticateAdmin(username, new String(password))) {
                    loggedInAdmin = username;
                    adminUsernameField.setEnabled(false);
                    adminPasswordField.setEnabled(false);
                    adminLoginButton.setEnabled(false);
                    logoutButton.setEnabled(true);
                    statusComboBox.setEnabled(true);
                    updateStatusButton.setEnabled(true);
                    updateAdminComplaints();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid admin credentials.");
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loggedInAdmin = null;
                adminUsernameField.setEnabled(true);
                adminPasswordField.setEnabled(true);
                adminLoginButton.setEnabled(true);
                logoutButton.setEnabled(false);
                statusComboBox.setEnabled(false);
                updateStatusButton.setEnabled(false);
                model.setRowCount(0);
            }
        });

        updateStatusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = adminComplaintsTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int complaintId = (int) adminComplaintsTable.getValueAt(selectedRow, 0);
                    String newStatus = statusComboBox.getSelectedItem().toString();
                    updateComplaintStatus(complaintId, newStatus);
                    updateAdminComplaints();
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a complaint to update status.");
                }
            }
        });
    }

    private boolean authenticateAdmin(String username, String password) {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:database.db");
            String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // If admin exists in database, return true
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            return false;
        }
    }

    private void updateAdminComplaints() {
        DefaultTableModel model = (DefaultTableModel) adminComplaintsTable.getModel();
        model.setRowCount(0);

        try {
            String query = "SELECT * FROM complaints";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int complaintId = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String complaint = resultSet.getString("complaint");
                String status = resultSet.getString("status");
                String role = resultSet.getString("role"); // Fetch role from the database
                model.addRow(new Object[]{complaintId, username, complaint, status, role}); // Add role to the table row
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void updateComplaintStatus(int complaintId, String newStatus) {
        try {
            String query = "UPDATE complaints SET status = ? WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newStatus);
            preparedStatement.setInt(2, complaintId);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        // Initialize database (create tables if not exists)
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String createAdminsTableQuery = "CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT, password TEXT)";
            String createComplaintsTableQuery = "CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY, username TEXT, complaint TEXT, status TEXT, role TEXT)";
            connection.createStatement().executeUpdate(createAdminsTableQuery);
            connection.createStatement().executeUpdate(createComplaintsTableQuery);

            // Add an admin (comment out after running once to avoid duplicate entries)
            String insertAdminQuery = "INSERT INTO admins (username, password) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertAdminQuery);
            preparedStatement.setString(1, "admin"); // Admin username
            preparedStatement.setString(2, "admin123"); // Admin password
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminManagementSystem().setVisible(true);
            }
        });
    }
}
