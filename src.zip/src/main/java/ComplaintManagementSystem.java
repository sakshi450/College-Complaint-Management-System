import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import javax.imageio.ImageIO;

// Base class representing a User
class User {
    private String username;
    private String password;
    private String role;

    // Constructor
    public User(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Common methods
    public boolean authenticate(String enteredPassword) {
        return this.password.equals(enteredPassword);
    }

    public void viewComplaints(String username, JTextArea complaintTextArea) {
        // Logic to view complaints based on the user's role
        // This method can be overridden in derived classes for role-specific behavior
        StringBuilder sb = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String query = "SELECT * FROM complaints WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String complaint = resultSet.getString("complaint");
                String status = resultSet.getString("status");
                String role = resultSet.getString("role");
                sb.append("\n\nComplaint: ").append(complaint).append(" \nStatus: ").append(status).append(" \nRole: ").append(role);
            }
            complaintTextArea.setText(sb.toString());
            complaintTextArea.setVisible(true); // Show the text area when viewing complaints
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }
}

// Derived class representing a Student
class Student extends User {
    public Student(String username, String password) {
        super(username, password, "Student");
    }

    // Additional methods or overrides specific to Student role can be added here
}

// Derived class representing a Staff
class Staff extends User {
    public Staff(String username, String password) {
        super(username, password, "Staff");
    }

    // Additional methods or overrides specific to Staff role can be added here
}

// Derived class representing a Faculty
class Faculty extends User {
    public Faculty(String username, String password) {
        super(username, password, "Faculty");
    }

    // Additional methods or overrides specific to Faculty role can be added here
}


public class ComplaintManagementSystem extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton loginButton;

    public ComplaintManagementSystem() {
        setTitle("College Complaint Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    Image backgroundImage = ImageIO.read(new File("image.jpg"));
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } catch (IOException e) {
                    e.printStackTrace();
                    // Handle image loading error
                }
            }
        };

        backgroundPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 20, 20, 20); // Padding

        JPanel loginBoxPanel = new JPanel();
        loginBoxPanel.setLayout(new BoxLayout(loginBoxPanel, BoxLayout.Y_AXIS));
        loginBoxPanel.setOpaque(true);
        loginBoxPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Padding

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        JLabel roleLabel = new JLabel("Role:");
        String[] roles = {"Student", "Faculty", "Staff"};
        roleComboBox = new JComboBox<>(roles);
        loginButton = new JButton("Login");

        loginBoxPanel.add(usernameLabel);
        loginBoxPanel.add(usernameField);
        loginBoxPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacing
        loginBoxPanel.add(passwordLabel);
        loginBoxPanel.add(passwordField);
        loginBoxPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacing
        loginBoxPanel.add(roleLabel);
        loginBoxPanel.add(roleComboBox);
        loginBoxPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing
        loginBoxPanel.add(loginButton);

        backgroundPanel.add(loginBoxPanel, gbc);

        setContentPane(backgroundPanel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);
                String role = (String) roleComboBox.getSelectedItem();

                if (authenticateUser(username, password, role)) {
                    dispose(); // Close the login window
                    openComplaintInterface(username, role);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username, password, or role.");
                }
            }
        });
    }

    private boolean authenticateUser(String username, String password, String role) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // If user exists in database, return true
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            return false;
        }
    }
    private void openComplaintInterface(String username, String role) {
        JFrame complaintFrame = new JFrame("Complaint Interface");
        complaintFrame.setSize(800, 400); // Set the frame size
        complaintFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create the top panel for buttons with BoxLayout
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        // Create the buttons
        JButton addComplaintButton = new JButton("Add Complaint");
        JButton viewComplaintsButton = new JButton("View Complaints");
        JButton hideComplaintsButton = new JButton("Hide Complaints");
        JButton logoutButton = new JButton("Logout");

        // Add buttons to the top panel
        topPanel.add(Box.createHorizontalGlue()); // Push buttons to the center
        topPanel.add(addComplaintButton);
        topPanel.add(viewComplaintsButton);
        topPanel.add(hideComplaintsButton);
        topPanel.add(logoutButton);
        topPanel.add(Box.createHorizontalGlue()); // Push buttons to the center

        // Create the text area
        JTextArea complaintTextArea = new JTextArea(1, 4);
        complaintTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(complaintTextArea);

        // Add components to the main panel
        mainPanel.add(topPanel, BorderLayout.NORTH); // Place buttons at the top
        mainPanel.add(scrollPane, BorderLayout.CENTER); // Place text area in the center

        // Set the content pane of the frame
        complaintFrame.setContentPane(mainPanel);
        complaintFrame.setVisible(true);

        // Initially hide the text area
        complaintTextArea.setVisible(false);

        // Action listeners for buttons
        addComplaintButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newComplaint = JOptionPane.showInputDialog(complaintFrame, "Enter your new complaint:");
                if (newComplaint != null && !newComplaint.trim().isEmpty()) {
                    insertComplaint(username, newComplaint, role);
                    updateComplaintTextArea(username, complaintTextArea);
                } else {
                    JOptionPane.showMessageDialog(complaintFrame, "Please enter a valid complaint.");
                }
            }
        });

        viewComplaintsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewComplaints(username, complaintTextArea);
            }
        });

        hideComplaintsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                complaintTextArea.setText(""); // Clear the text area to hide complaints
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                complaintFrame.dispose(); // Close the complaint interface window
                setVisible(true); // Show the login window again
            }
        });
    }

    private void viewComplaints(String username, JTextArea complaintTextArea) {
        StringBuilder sb = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String query = "SELECT * FROM complaints WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String complaint = resultSet.getString("complaint");
                String status = resultSet.getString("status");
                String role = resultSet.getString("role");
                sb.append("\n\nComplaint: ").append(complaint).append(" \nStatus: ").append(status).append(" \nRole: ").append(role);
            }
            complaintTextArea.setText(sb.toString());
            complaintTextArea.setVisible(true); // Show the text area when viewing complaints
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }



    private void insertComplaint(String username, String complaint, String role) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String query = "INSERT INTO complaints (username, complaint, status, role) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, complaint);
            preparedStatement.setString(3, "Pending");
            preparedStatement.setString(4, role);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void updateComplaintTextArea(String username, JTextArea complaintTextArea) {
        StringBuilder sb = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String query = "SELECT * FROM complaints WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String complaint = resultSet.getString("complaint");
                String status = resultSet.getString("status");
                String role = resultSet.getString("role");
                sb.append("\n\nComplaint: ").append(complaint).append(" \nStatus: ").append(status).append(" \nRole: ").append(role);
            }
            complaintTextArea.setText(sb.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void addUser(String username, String password, String role) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String insertQuery = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String createUserTableQuery = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT)";
            String createComplaintsTableQuery = "CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY, username TEXT, complaint TEXT, status TEXT, role TEXT)";
            connection.createStatement().executeUpdate(createUserTableQuery);
            connection.createStatement().executeUpdate(createComplaintsTableQuery);

            // Adding users (comment out after running once to avoid duplicate entries)
            new ComplaintManagementSystem().addUser("sakshi", "123", "Student");
            new ComplaintManagementSystem().addUser("prachee", "123", "Student");
            new ComplaintManagementSystem().addUser("rahul", "123", "Student");
            new ComplaintManagementSystem().addUser("shivesh", "123", "Student");
            new ComplaintManagementSystem().addUser("nancy", "123", "Student");

            new ComplaintManagementSystem().addUser("f1", "123", "Faculty");
            new ComplaintManagementSystem().addUser("f2", "123", "Faculty");
            new ComplaintManagementSystem().addUser("f3", "123", "Faculty");
            new ComplaintManagementSystem().addUser("f4", "123", "Faculty");
            new ComplaintManagementSystem().addUser("f5", "123", "Faculty");

            new ComplaintManagementSystem().addUser("s1", "123", "Staff");
            new ComplaintManagementSystem().addUser("s2", "123", "Staff");
            new ComplaintManagementSystem().addUser("s3", "123", "Staff");
            new ComplaintManagementSystem().addUser("s4", "123", "Staff");
            new ComplaintManagementSystem().addUser("s5", "123", "Staff");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ComplaintManagementSystem().setVisible(true);
            }
        });
    }
}
