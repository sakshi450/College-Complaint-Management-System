import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ComplaintPanel extends JPanel {
    private JTextArea complaintTextArea;
    private JButton submitButton;

    public ComplaintPanel() {
        setLayout(new BorderLayout());
        setOpaque(true); // Make panel transparent

        JLabel titleLabel = new JLabel("Enter Your Complaint:");
        complaintTextArea = new JTextArea(10, 30);
        JScrollPane scrollPane = new JScrollPane(complaintTextArea);
        submitButton = new JButton("Submit Complaint");

        // Create a panel for components
        JPanel componentsPanel = new JPanel(new BorderLayout());
        componentsPanel.setOpaque(false); // Make panel transparent
        componentsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding
        componentsPanel.add(titleLabel, BorderLayout.NORTH);
        componentsPanel.add(scrollPane, BorderLayout.CENTER);
        componentsPanel.add(submitButton, BorderLayout.SOUTH);

        // Create a panel for centering components
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(true); // Make panel transparent
        centerPanel.add(componentsPanel);

        // Add centered panel to the main panel
        add(centerPanel, BorderLayout.CENTER);
    }

    public JTextArea getComplaintTextArea() {
        return complaintTextArea;
    }

    public JButton getSubmitButton() {
        return submitButton;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Complaint Panel");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(400, 300);

                JPanel backgroundPanel = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        try {
                            Image backgroundImage = ImageIO.read(new File("image.jpg"));
                            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                        } catch (IOException e) {
                            e.printStackTrace();
                            // Handle image loading error
                        }
                    }
                };

                backgroundPanel.setLayout(new GridBagLayout());
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.fill = GridBagConstraints.CENTER;
                backgroundPanel.add(new ComplaintPanel(), gbc);

                frame.setContentPane(backgroundPanel);
                frame.setVisible(true);
            }
        });
    }
}
