import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseSetup {
    private static final String DATABASE_URL = "jdbc:sqlite:database.db";

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading SQLite JDBC driver: " + e.getMessage());
        }
    }

    public static void createTable() {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL);
             PreparedStatement statement = connection.prepareStatement(
                     "CREATE TABLE IF NOT EXISTS complaints (" +
                             "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                             "username TEXT," +
                             "complaint TEXT," +
                             "status TEXT," +
                             "role TEXT" + // Add the role column here
                             ")")) {
            statement.executeUpdate();
            System.out.println("Database table 'complaints' created successfully.");
        } catch (SQLException e) {
            System.err.println("Error creating database table: " + e.getMessage());
        }
    }

    public static void insertComplaint(String username, String complaint, String role) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO complaints (username, complaint, status, role) VALUES (?, ?, ?, ?)")) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, complaint);
            preparedStatement.setString(3, "Pending"); // Initial status is "Pending"
            preparedStatement.setString(4, role); // Add role to the insert statement
            preparedStatement.executeUpdate();
            System.out.println("Complaint inserted successfully.");
        } catch (SQLException e) {
            System.err.println("Error inserting complaint: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        createTable(); // Create the table when running DatabaseSetup
    }
}
